# Copyright (c) 2020 Yahboom Team
# Author: chengengyue
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
# THE SOFTWARE.

import time
import os
import Adafruit_Nokia_LCD as LCD

from PIL import Image
from PIL import ImageDraw
from PIL import ImageFont

import subprocess

# Raspberry Pi software SPI config:
SCLK = 17
DIN = 18
DC = 27
RST = 23
CS = 22

# Software SPI usage (defaults to bit-bang SPI interface):
disp = LCD.PCD8544(DC, RST, SCLK, DIN, CS)

# Initialize library.
disp.begin(contrast=60)

# Clear display.
disp.clear()
disp.display()

# Create blank image for drawing.
# Make sure to create image with mode '1' for 1-bit color.
width = LCD.LCDWIDTH
height = LCD.LCDHEIGHT
image = Image.new('1', (width, height))

# Get drawing object to draw on image.
draw = ImageDraw.Draw(image)

# Draw a white filled box to clear the image.
draw.rectangle((0,0,LCD.LCDWIDTH,LCD.LCDHEIGHT), outline=255, fill=255)

# Load default font.
font = ImageFont.load_default()

# Alternatively load a TTF font.
# Some nice fonts to try: http://www.dafont.com/bitmap.php
# font = ImageFont.truetype('Minecraftia.ttf', 8)

# First define some constants to allow easy resizing of shapes.
padding = -2
top = padding
bottom = height-padding
# Move left to right keeping track of the current x position for drawing shapes.
x = 0


print('Press Ctrl-C to quit.')
while True:
    # Draw a black filled box to clear the image.
    draw.rectangle((0,0,width,height), outline=255, fill=255)
    ''' IP '''
    # cmd = "hostname -I | cut -d\' \' -f1"
    # IP = subprocess.check_output(cmd, shell = True )

    '''uptime'''
    uptimems = os.popen('cat /proc/uptime').readline().split( )
    uptimemin = int(float(uptimems[0]) / 60)

    ''' cpuUsage '''
    time1 = os.popen('cat /proc/stat').readline().split()[1:5]
    time.sleep(0.2)
    time2 = os.popen('cat /proc/stat').readline().split()[1:5]
    deltaUsed = int(time2[0])-int(time1[0])+int(time2[2])-int(time1[2])
    deltaTotal = deltaUsed + int(time2[3])-int(time1[3])
    cpuUsage = int(float(deltaUsed)/float(deltaTotal)*100)

    ''' cputemp '''
    file = open("/sys/class/thermal/thermal_zone0/temp")
    temp = float(file.read()) / 1000.0
    temp = round(temp, 1)
    file.close()

    ''' freeRAM '''
    RAM = os.popen('free').read().split()[7:10]
    RAM = int(RAM[2])/1024

    # draw.text((x, top), str(IP), font=font)   # IP
    draw.text((x, top), "Raspberry Pi 4", font=font)
    draw.line((0, top+11, 84, top+11), fill=0)
    draw.text((x, top+12), "Uptime " + str(uptimemin) + " min", font=font)
    draw.text((x, top+21), "CPU: " + str(cpuUsage) + " %", font=font)
    draw.text((x, top+30), "RAM: " + str(RAM) + " MB", font=font)
    draw.text((x, top+39), "temp:" + str(temp) + " C", font=font)

    # Display image.
    disp.image(image)
    disp.display()
    time.sleep(1)
