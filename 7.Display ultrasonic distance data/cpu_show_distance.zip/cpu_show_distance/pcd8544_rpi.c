/*
=================================================================================
 Name        : pcd8544_rpi.c
 Version     : 3.0

##############################
 modify code by rei1984 @ Raspifans.com 
 add IP address. 20160316
 add CPU thermal degree 20160521
##############################

 Copyright (C) 2012 by Andre Wussow, 2012, desk@binerry.de

 Description :
     A simple PCD8544 LCD  for Raspberry Pi for displaying some system informations.
	 Makes use of WiringPI-library of Gordon Henderson (https://projects.drogon.net/raspberry-pi/wiringpi/)

	 Recommended connection (http://www.raspberrypi.org/archives/384):
	 LCD pins      Raspberry Pi
	 LCD1 - GND    P06  - GND
	 LCD2 - VCC    P01 - 3.3V
	 LCD3 - CLK    P11 - GPIO0
	 LCD4 - Din    P12 - GPIO1
	 LCD5 - D/C    P13 - GPIO2
	 LCD6 - CS     P15 - GPIO3
	 LCD7 - RST    P16 - GPIO4
	 LCD8 - LED    P01 - 3.3V

================================================================================
This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Lesser General Public
License as published by the Free Software Foundation; either
version 2.1 of the License, or (at your option) any later version.

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Lesser General Public License for more details.
================================================================================
 */
#include <wiringPi.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/sysinfo.h>
#include "PCD8544.h"


// pin setup
int _din = 1;
int _sclk = 0;
int _dc = 2;
int _rst = 4;
int _cs = 3;

//Define the EchoPin connect to wiringPi port 30 of Raspberry pi
//Define the TrigPin connect to wiringPi port 31 of Raspberry pi
int EchoPin = 30;
int TrigPin = 31;

// lcd contrast
//may be need modify to fit your screen!  normal: 30- 90 ,default is:45 !!!maybe modify this value!
int contrast = 45;

//return distance data
float Distance()
{
  float distance;
  struct timeval tv1;
  struct timeval tv2;
  struct timeval tv3;
  struct timeval tv4;
  long start, stop;

  digitalWrite(TrigPin, LOW);
  delayMicroseconds(2);
  //Input a high level of at least 10 US to the Trig pin
  digitalWrite(TrigPin, HIGH);
  delayMicroseconds(15);
  digitalWrite(TrigPin, LOW);

  //Add a timeout retest mechanism to prevent the program did not detect a level change, 
  //get stuck in an infinite loop
  gettimeofday(&tv3, NULL);
  //Timeout retest mechanism is starting
  start = tv3.tv_sec * 1000000 + tv3.tv_usec;
  while(!digitalRead(EchoPin) == 1)
  {
    gettimeofday(&tv4, NULL);
    //Timeout retest mechanism is ending
    stop = tv4.tv_sec * 1000000 + tv4.tv_usec;
    //Maximum time value (5m)：10/340=0.03s
    if ((stop - start) > 30000)
    {
      return -1;
    }
  }

  gettimeofday(&tv1, NULL);
  start = tv1.tv_sec*1000000+tv1.tv_usec;
  while(!digitalRead(EchoPin) == 0)
  {
    gettimeofday(&tv3,NULL);
    stop = tv3.tv_sec*1000000+tv3.tv_usec;
    if ((stop - start) > 30000)
    {
      return -1;
    }
  }
  gettimeofday(&tv2, NULL);

  start = tv1.tv_sec * 1000000 + tv1.tv_usec;
  stop = tv2.tv_sec * 1000000 + tv2.tv_usec;

  distance = (float)(stop - start)/1000000 * 34000 / 2;
  return distance;
}

//Bubble sorting
void bubble(unsigned long *a, int n)
{
  int i, j, temp;
  for (i = 0; i < n - 1; i++)
  {
    for (j = i + 1; j < n; j++)
    {
      if (a[i] > a[j])
      {
        temp = a[i];
        a[i] = a[j];
        a[j] = temp;
      }
    }
  }
}

//Remove the maximum, minimum of the 5 datas
//and get average values of 3 datas to improve accuracy of test
float Distance_test()
{
  float distance;
  unsigned long ultrasonic[5] = {0};
  int num = 0;
  while (num < 5)
  {
    distance = Distance();

    while((int)distance == -1)
    {
      distance = Distance();
    }
    //Filter out data greater than 500 or smaller than 0 in the test distance
    while ( (int)distance >= 500 || (int)distance == 0)
    {
      distance = Distance();
    }
    ultrasonic[num] = distance;
    num++;
    delay(10);
  }
  num = 0;
  //Bubble sorting
  bubble(ultrasonic, 5);
  //Average
  distance = (ultrasonic[1] + ultrasonic[2] + ultrasonic[3]) / 3;

  printf("distance= %.0fcm\n",distance);
  return distance;
}


int main (void)
{
  // print infos
  printf("Raspberry Pi PCD8544 sysinfo display\n");
  printf("========================================\n");

  // check wiringPi setup
  if (wiringPiSetup() == -1)
  {
    printf("wiringPi-Error\n");
    exit(1);
  }
  //Initialize ultrasonic pin
  pinMode(EchoPin, INPUT);
  pinMode(TrigPin, OUTPUT);

  //CurrentDistance
  char CurrentDistance[15];
  float distance = 0;

  // init and clear lcd
  LCDInit(_sclk, _din, _dc, _cs, _rst, contrast);
  LCDclear();
  delay(500);

  for (;;)
  {
    // clear lcd
    LCDclear();
    //get current distance data
    distance = Distance_test();

    sprintf(CurrentDistance,"distance:%.0fcm",distance);

    // build screen
    //LCDdrawstring(0, 0, "Raspberry Pi:");

    LCDdrawstring(0, 1, "Hello YahBoom!");
    LCDdrawline(0, 10, 83, 10, BLACK);

    LCDdrawstring(0, 21, CurrentDistance);

    LCDdisplay();

    delay(1000);
  }

  return 0;
}
